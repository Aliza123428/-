import express from 'express';
import Menu from '../models/Menu';

const router = express.Router();

// Create a new menu item
router.post('/', async (req, res) => {
  const { name, description, price, photo } = req.body;
  const newMenuItem = new Menu({ name, description, price, photo });
  try {
    await newMenuItem.save();
    res.status(201).json(newMenuItem);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
});

// Get all menu items
router.get('/', async (req, res) => {
  try {
    const menuItems = await Menu.find();
    res.status(200).json(menuItems);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

export default router;