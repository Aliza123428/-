import express from 'express';
import mongoose from 'mongoose';
import bodyParser from 'body-parser';
import menuRoutes from './routes/menuRoutes';
import orderRoutes from './routes/orderRoutes';

const app = express();
const PORT = process.env.PORT || 5000;

app.use(bodyParser.json());

mongoose.connect('mongodb://localhost:27017/qrcode_menu', {
  useNewUrlParser: true,
  useUnifiedTopology: true
}).then(() => {
  console.log('Connected to MongoDB');
}).catch((error) => {
  console.error('Error connecting to MongoDB:', error);
});

app.use('/api/menu', menuRoutes);
app.use('/api/order', orderRoutes);

app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});