import React, { useState } from 'react';
import axios from 'axios';

const OrderForm: React.FC = () => {
  const [items, setItems] = useState([]);
  const [totalAmount, setTotalAmount] = useState(0);

  const handleOrder = async () => {
    const response = await axios.post('/api/order', { items, totalAmount });
    console.log(response.data);
  };

  return (
    <div>
      <h1>Order</h1>
      <button onClick={handleOrder}>Place Order</button>
    </div>
  );
}

export default OrderForm;