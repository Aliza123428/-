import React from 'react';
import { useQRCode } from 'react-qrcode';

const QRCodeScanner: React.FC<{ text: string }> = ({ text }) => {
  const { url } = useQRCode({
    text,
    options: {
      level: 'H',
      width: 256,
    },
  });

  return <img src={url} alt="QR Code" />;
}

export default QRCodeScanner;