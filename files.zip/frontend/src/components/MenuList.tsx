import React from 'react';

const MenuList: React.FC<{ menu: any[] }> = ({ menu }) => {
  return (
    <div>
      <ul>
        {menu.map((item: any) => (
          <li key={item._id}>
            <h2>{item.name}</h2>
            <p>{item.description}</p>
            <p>{item.price}</p>
            <img src={item.photo} alt={item.name} />
          </li>
        ))}
      </ul>
    </div>
  );
}

export default MenuList;