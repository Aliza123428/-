import React, { useEffect, useState } from 'react';
import axios from 'axios';

const MenuPage: React.FC = () => {
  const [menu, setMenu] = useState([]);

  useEffect(() => {
    const fetchMenu = async () => {
      const response = await axios.get('/api/menu');
      setMenu(response.data);
    };

    fetchMenu();
  }, []);

  return (
    <div>
      <h1>Menu</h1>
      <ul>
        {menu.map((item: any) => (
          <li key={item._id}>
            <h2>{item.name}</h2>
            <p>{item.description}</p>
            <p>{item.price}</p>
            <img src={item.photo} alt={item.name} />
          </li>
        ))}
      </ul>
    </div>
  );
}

export default MenuPage;